"""
Author         : Jie Li, Innovision IP Ltd and School of Mathematics, Statistics and Actuarial Science, University of Kent.
Date           : 2024-01-20 23:30:09
Last Revision  : 2024-01-20 23:53:25
Last Author    : Jie Li
File Path      : /skewt_scipy/test/test.py
Description    :








Copyright (c) 2024, Jie Li, jl725@kent.ac.uk
All Rights Reserved.
"""
from skewt_scipy.skewt import skewt

skewt.rvs(a=10, df=6, loc=3, scale=2, size=10)
