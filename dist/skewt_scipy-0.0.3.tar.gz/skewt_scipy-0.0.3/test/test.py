"""
Author         : Jie Li, Innovision IP Ltd and School of Mathematics, Statistics and Actuarial Science, University of Kent.
Date           : 2024-01-20 23:30:09
Last Revision  : 2024-01-20 23:32:45
Last Author    : Jie Li
File Path      : /skewt-scipy/test/test.py
Description    :








Copyright (c) 2024, Jie Li, jl725@kent.ac.uk
All Rights Reserved.
"""
import skewt_scipy as ss
